#include "stdafx.h"
#include "Component.h"
#include "Object.h"
