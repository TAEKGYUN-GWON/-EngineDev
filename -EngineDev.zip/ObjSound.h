#pragma once
#include "Component.h"
class ObjSound : public Component
{
	vector<string> _vSoundList;
public:
	ObjSound();
	~ObjSound();
};

