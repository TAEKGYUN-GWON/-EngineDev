#pragma once
class test : public Object
{

public:
	test();
	~test();
};

