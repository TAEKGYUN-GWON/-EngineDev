#include "stdafx.h"
#include "DrawComponent.h"
#include"Transform.h"


DrawComponent::DrawComponent()
{
}


DrawComponent::~DrawComponent()
{
}
