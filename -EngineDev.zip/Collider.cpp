#include "stdafx.h"
#include "Collider.h"


Collider::Collider()
{
	_name = "Collider";
}


Collider::~Collider()
{
}
