#include "stdafx.h"
#include "ObjSound.h"


ObjSound::ObjSound()
{
}


ObjSound::~ObjSound()
{
}
