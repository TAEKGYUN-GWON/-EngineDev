#pragma once
#include "enemy.h"

class minion2 : public enemy
{
public:
	minion2();
	~minion2();
};

